<?php
/**
 * WHMCS KwikPaisa Payment Gateway Module
 */
if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}
/**
 * Define module related meta data.
 * @return array
 */
function kwikpaisa_MetaData()
{
    return array(
        'DisplayName' => 'KwikPaisa NEO Bank',
        'APIVersion' => '1.0.1',
        'DisableLocalCredtCardInput' => true,
        'TokenisedStorage' => false,
    );
}
/**
 * Define KwikPaisa gateway configuration options.
 * @return array
 */
function kwikpaisa_config()
{
    return array(
        'FriendlyName' => array(
            'Type' => 'System',
            'Value' => 'KwikPaisa',
        ),
        'appId' => array(
            'FriendlyName' => 'MID Key',
            'Type' => 'text',
            'Size' => '50',
            'Description' => 'KwikPaisa "MID Key". Available <a href="https://www.kwikpaisa.com/" target="_blank" style="bottom-border:1px dotted;">HERE</a>',
        ),
        'secretKey' => array(
            'FriendlyName' => 'MID Secret Key',
            'Type' => 'password',
            'Size' => '50',
            'Description' => 'KwikPaisa "MID Secret Key" shared during activation API Key',
        ),
        'testMode' => array(
            'FriendlyName' => 'Test Mode',
            'Type' => 'yesno',
            'Description' => 'Tick to enable test mode',
        ),
    );
}
//Create Payment for KwikPaisa NEO Bank Payment Platform
function kwikpaisa_link($params)
{
   // Invoice Parameters
    $invoiceId      = $params['invoiceid'];
   // $ordervalue         = $params['amount'];
    $ordervalue         = round($params['amount']);
    // Client Parameters
    $firstname      = $params['clientdetails']['firstname'];
    $lastname       = $params['clientdetails']['lastname'];
    // System Parameters
    $systemUrl      = $params['systemurl'];
    $returnUrl      = $params['returnurl'];
    $moduleName     = $params['paymentmethod'];
    //KwikPaisa Auth Parameters
	if ($params['testMode'] == 'on') 
	{$KP_ENVIRONMENT = "TEST";} 
	else 
	{$KP_ENVIRONMENT = "LIVE";}
    $paramList = array();
    $paramList["KP_ENVIRONMENT"] = $KP_ENVIRONMENT;
    $paramList["KPMID"] = $params['appId'];
    $paramList["KPMIDKEY"] = $params['secretKey'];
    $paramList["TXN_CURRENCY"] = $params['currency'];
// KwikPaisa Parameters For submit Payment
    $kwikpaisa_request                     = array();
	//Customer Details
    $kwikpaisa_request['KP_ENVIRONMENT']   = $paramList["KP_ENVIRONMENT"];
    $kwikpaisa_request['KPMID']            = $paramList["KPMID"];
    $kwikpaisa_request['KPMIDKEY']         = $paramList["KPMIDKEY"];
    $kwikpaisa_request['CUST_NAME']         = $firstname.' '.$lastname;
    $kwikpaisa_request['CUST_EMAIL']      = $params['clientdetails']['email'];
    $kwikpaisa_request['CUST_MOBILE']    = $params['clientdetails']['phonenumber'];
    $kwikpaisa_request['CUST_ADDRESS_LINE1']        = $params['clientdetails']['address1'];
    $kwikpaisa_request['CUST_ADDRESS_LINE2']        = $params['clientdetails']['address2'];
    $kwikpaisa_request['CUST_ADDRESS_CITY']        = $params['clientdetails']['city'];
    $kwikpaisa_request['CUST_ADDRESS_STATE']        = $params['clientdetails']['state'];
    $kwikpaisa_request['CUST_ADDRESS_COUNTRY']        = $params['clientdetails']['country'];
    $kwikpaisa_request['CUST_ADDRESS_POSTAL_CODE']        = $params['clientdetails']['postcode'];
	////Order Detailas
    $kwikpaisa_request['TXN_CURRENCY']        = $paramList["TXN_CURRENCY"];
    $kwikpaisa_request['TXN_AMOUNT']        = $ordervalue;
    $kwikpaisa_request['ORDER_ID']        = $invoiceId;
	////CallbackURL
    $kwikpaisa_request['KP_Return_URL']        = $systemUrl . 'modules/gateways/callback/' . $moduleName . '.php';
    //$kwikpaisa_request['notifyUrl']        = $systemUrl . 'modules/gateways/callback/' . $moduleName . '_notify.php';
    //$kwikpaisa_request['source']           = "whmcs";
     ///Payment Submit URL
    //$PayOrder=$systemUrl . 'modules/gateways/KwikPaisaProcess.php';
    $langPayNow = $params['langpaynow'];
    //$apiEndpoint = $PayOrder;  
    $url = $systemUrl."modules/gateways/KwikPaisaProcess.php";
    $htmlOutput = '<form method="post" action="' . $url . '">';
    foreach ($kwikpaisa_request as $k => $v) {
    $htmlOutput .= '<input type="hidden" name="' . $k . '" value="' . ($v) . '" />';
    }
    $htmlOutput .= '<input type="submit" value="' . $langPayNow . '" />';
    $htmlOutput .= '</form>';

    return $htmlOutput;
}