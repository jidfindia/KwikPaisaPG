<?php
/**
 * WHMCS KwikPaisa Payment Gateway Module
 */
if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}
/**
 * Define module related meta data.
 * @return array
 */
function kwikpaisa_MetaData()
{
    return array(
        'DisplayName' => 'KwikPaisa NEO Bank',
        'APIVersion' => '1.0.1',
        'DisableLocalCredtCardInput' => true,
        'TokenisedStorage' => false,
    );
}
/**
 * Define KwikPaisa gateway configuration options.
 * @return array
 */
function kwikpaisa_config()
{
    return array(
        'FriendlyName' => array(
            'Type' => 'System',
            'Value' => 'KwikPaisa',
        ),
        'appId' => array(
            'FriendlyName' => 'MID Key',
            'Type' => 'text',
            'Size' => '50',
            'Description' => 'KwikPaisa "MID Key". Available <a href="https://www.kwikpaisa.com/" target="_blank" style="bottom-border:1px dotted;">HERE</a>',
        ),
        'secretKey' => array(
            'FriendlyName' => 'MID Secret Key',
            'Type' => 'password',
            'Size' => '50',
            'Description' => 'KwikPaisa "MID Secret Key" shared during activation API Key',
        ),
        'testMode' => array(
            'FriendlyName' => 'Test Mode',
            'Type' => 'yesno',
            'Description' => 'Tick to enable test mode',
        ),
    );
}
//Create Payment for KwikPaisa NEO Bank Payment Platform
function kwikpaisa_link($params)
{
   // Invoice Parameters
    $invoiceId      = $params['invoiceid'];
   // $ordervalue         = $params['amount'];
    $ordervalue         = round($params['amount']);
    // Client Parameters
    $firstname      = $params['clientdetails']['firstname'];
    $lastname       = $params['clientdetails']['lastname'];
	//Customer Name Passed to KwikPaisa NEO Bank Payment Platform
	$custname = $firstname.' '.$lastname;
    $custemail          = $params['clientdetails']['email'];
    $custmobile          = $params['clientdetails']['phonenumber'];
    $custaddressline1          = $params['clientdetails']['address1'];
    $custaddressline2          = $params['clientdetails']['address2'];
    $custaddresscity          = $params['clientdetails']['city'];
    $custaddressstate          = $params['clientdetails']['state'];
    $custaddresscountry          = $params['clientdetails']['country'];
    $custaddresspostalcode          = $params['clientdetails']['postalcode'];
    // System Parameters
    $systemUrl      = $params['systemurl'];
    $returnUrl      = $params['returnurl'];
    $moduleName     = $params['paymentmethod'];
    //KwikPaisa Auth Parameters
	if ($params['testMode'] == 'on') 
	{$KP_ENVIRONMENT = "TEST";} 
	else 
	{$KP_ENVIRONMENT = "LIVE";}
    $paramList = array();
    $paramList["KP_ENVIRONMENT"] = $KP_ENVIRONMENT;
    $paramList["KPMID"] = $params['appId'];
    $paramList["KPMIDKEY"] = $params['secretKey'];
    $paramList["TXN_CURRENCY"] = $params['currency'];
	///Create Customer From API Pass Customer Parameters to https://pispp.kwikpaisa.com/API/v1/CreateCustomer
$curl = curl_init();
curl_setopt_array($curl, array(
CURLOPT_URL => 'https://pispp.kwikpaisa.com/API/v1/CreateCustomer',
CURLOPT_RETURNTRANSFER => true,
CURLOPT_ENCODING => '',
CURLOPT_MAXREDIRS => 10,
CURLOPT_TIMEOUT => 0,
CURLOPT_FOLLOWLOCATION => true,
CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
CURLOPT_CUSTOMREQUEST => 'POST',
CURLOPT_POSTFIELDS => array('KP_ENVIRONMENT' => $paramList["KP_ENVIRONMENT"],'KPMID' => $paramList["KPMID"],'KPMIDKEY' => $paramList["KPMIDKEY"],'CUST_NAME' => $custname,'CUST_EMAIL' => $custemail,'CUST_MOBILE' => $custmobile,'CUST_ADDRESS_LINE1' => $custaddressline1,'CUST_ADDRESS_LINE2' => $custaddressline2,'CUST_ADDRESS_CITY' => $custaddresscity,'CUST_ADDRESS_STATE' => $custaddressstate,'CUST_ADDRESS_COUNTRY' => $custaddresscountry,'CUST_ADDRESS_POSTAL_CODE' => $custaddresspostalcode),
));
$response = curl_exec($curl);
curl_close($curl);
$response;
//Make Variable of Customer ID Received From API Call
$customerId=json_decode(($response),true);
$customerIdvalue=$customerId["CUST_KP_ID"];
///Now Create Order ID and Payment Token By Passing Parameters To https://pispp.kwikpaisa.com/API/v1/Order
$curl = curl_init();
curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://pispp.kwikpaisa.com/API/v1/Order',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS => array('KP_ENVIRONMENT' => $paramList["KP_ENVIRONMENT"],'KPMID' => $paramList["KPMID"],'KPMIDKEY' => $paramList["KPMIDKEY"],'CUST_KP_ID' => $customerIdvalue,'TXN_CURRENCY' => $paramList["TXN_CURRENCY"],'TXN_AMOUNT' => $ordervalue,'ORDER_ID' => $invoiceId),
));
$response = curl_exec($curl);
curl_close($curl);
$response;
//Make Variable of Customer ID Received From API Call
$OrderDetails=json_decode(($response),true);
$KP_Txn_OrderID=$OrderDetails["KP_Txn_OrderID"];
$KP_Txn_Signature=$OrderDetails["KP_Txn_Signature"];
$KP_Txn_Token=$OrderDetails["KP_Txn_Token"];
// KwikPaisa Parameters For submit Payment
    $kwikpaisa_request                     = array();
    $kwikpaisa_request['KPMID']            = $paramList["KPMID"];
    $kwikpaisa_request['CUST_KP_ID']          = $customerIdvalue;
    $kwikpaisa_request['KP_Txn_OrderID']      = $KP_Txn_OrderID;
    $kwikpaisa_request['KP_Txn_Signature']    = $KP_Txn_Signature;
    $kwikpaisa_request['KP_Txn_Token']        = $KP_Txn_Token;
    $kwikpaisa_request['KP_Return_URL']        = $systemUrl . 'modules/gateways/callback/' . $moduleName . '.php';
    //$kwikpaisa_request['notifyUrl']        = $systemUrl . 'modules/gateways/callback/' . $moduleName . '_notify.php';
    //$kwikpaisa_request['source']           = "whmcs";

    $langPayNow = $params['langpaynow'];
    $apiEndpoint = 'https://pispp.kwikpaisa.com';  
    $url = $apiEndpoint."/CheckOut/TxnProcess";
    $htmlOutput = '<form method="post" action="' . $url . '">';
    foreach ($kwikpaisa_request as $k => $v) {
    $htmlOutput .= '<input type="hidden" name="' . $k . '" value="' . ($v) . '" />';
    }
    $htmlOutput .= '<input type="submit" value="' . $langPayNow . '" />';
    $htmlOutput .= '</form>';

    return $htmlOutput;
}